#!/bin/bash
function end()
{
    reap -p "Press any button to exit"
}
echo "loading..."
java -jar "Rubik's cube simulator.jar"
end
