echo "loading..."
java -jar "Rubik's cube.jar"
PAUSE
